//
//  GalaryCollectionViewCell.swift
//  Signup & SignIn
//
//  Created by Mac Mini on 17/04/23.
//

import UIKit
class GalaryCollectionViewCell: UICollectionViewCell {
    @IBOutlet var lblimgcount: UILabel!
    @IBOutlet var lblimgname: UILabel!
    @IBOutlet var image: UIImageView!
}
