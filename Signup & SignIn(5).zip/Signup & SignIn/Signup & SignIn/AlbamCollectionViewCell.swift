//
//  AlbamCollectionViewCell.swift
//  Signup & SignIn
//
//  Created by Mac Mini on 01/05/23.
//

import UIKit

class AlbamCollectionViewCell: UICollectionViewCell {
    @IBOutlet var imageView: UIImageView!
}
