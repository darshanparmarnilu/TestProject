//
//  TabbarViewController.swift
//  Signup & SignIn
//
//  Created by MacBookAir_4 on 04/05/23.
//

import UIKit

class TabbarViewController: UITabBarController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
