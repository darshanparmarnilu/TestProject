//
//  albamViewController.swift
//  Signup & SignIn
//
//  Created by Mac Mini on 13/04/23.
//

import UIKit

class albamViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    


}
